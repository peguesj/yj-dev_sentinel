# Copilot Chat Recovery Automation

This package contains AppleScript automation to resolve common VS Code Copilot Chat issues.

## Usage

Run the scripts using:

```bash
osascript scripts/reload_vscode.applescript
```
